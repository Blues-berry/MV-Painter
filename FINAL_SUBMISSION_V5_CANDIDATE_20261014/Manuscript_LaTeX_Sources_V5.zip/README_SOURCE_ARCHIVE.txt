V5 manuscript source archive

This archive contains the main manuscript and Supplement sources, all figures and tables they require, and the local Elsevier class/style/logo files. All files are stored at one directory level for Editorial Manager.

Compile from this directory with pdfLaTeX, running each command three times:
  pdflatex -interaction=nonstopmode -halt-on-error FINAL_V5_MANUSCRIPT.tex
  pdflatex -interaction=nonstopmode -halt-on-error FINAL_V5_SUPPLEMENTARY.tex
The bibliography is embedded in FINAL_V5_MANUSCRIPT.tex; no separate .bib or .bst is needed.
