Computers & Graphics — V6 evaluation-focused revision
Manuscript CAG-D-26-00962 | first-round submission CAG-S-26-01549

UPLOAD_FILES contains 23 prepared files: clean manuscript, marked manuscript, Supplement, response in PDF and editable DOCX, separate Title Page, Cover Letter, Highlights, competing-interest declaration, Graphical Abstract, separate main-manuscript and Supplement LaTeX source ZIPs, Figures 1–4, data CSV, Paper 75 comparison PDF, and both supplementary videos with stills and captions. Upload journal items individually; the outer ZIP is a handoff archive.

Page counts: clean manuscript 13; Marked Manuscript 13; Supplement 71; Response 5. In the marked manuscript, additions and replacement text are red and deleted text is omitted. The comparison baseline is the authenticated 01549 source.

The Abstract now synthesizes the applied-interface, equal-applied-sum and baked-appearance findings. The Introduction now describes the contribution as an implementation-aware empirical framework for evaluating geometry-control allocation. Reviewer 2 Concern 1 opens with the revised claim and is about 12% shorter while retaining the primary contrast, retrospective comparisons, and scope boundaries. Data availability explains that object-level metrics are released only where source permissions allow derived-metric redistribution; full-cohort summaries remain in the manuscript and Supplement. The Paper 75 relationship remains disclosed in the Introduction, while the Abstract and Conclusion read as an independent empirical account. Historical 3AFC and FAC records remain in Supplement S7 and the FAC response, not as isolated main-text evidence. Main Table 8 summarizes all four frozen full-V29 endpoints from Supplement Table S37. No cohort, statistic, image, or experimental output changed.

The public limited research-data release remains Zenodo v1.0.1, DOI 10.5281/zenodo.23383807; the package also contains the native/default per-object CSV. The main-manuscript and Supplement source ZIPs independently rebuild to 13 and 71 pages. The response DOCX and PDF contain matching revised text, including the evidence-scope paragraphs and first-round continuity table.

Funding acknowledgement follows the September 7 Title Page at the author's direction. No additional funder-role statement was added. No journal-portal submission was performed.

AUTHOR_REVIEW_READY: YES
SUBMISSION_READY: YES — prepared file package is ready for author upload; verify portal metadata, file roles and the generated proof during submission.

Final wording pass (2026-10-15): the historical +0.96 dB response now explicitly retires that claim and identifies Fresh C as current evidence; the response reframes evidence boundaries, and the continuity table is compacted to fit on page 5. The Introduction now states the evaluation questions directly. No statistics, cohorts, outputs, or figures changed.

LaTeX sources are supplied as two independent archives: Main_Manuscript_LaTeX_Source_V6.zip and Supplementary_LaTeX_Source_V6.zip. Each includes its own entry-point .tex file and local dependencies.
