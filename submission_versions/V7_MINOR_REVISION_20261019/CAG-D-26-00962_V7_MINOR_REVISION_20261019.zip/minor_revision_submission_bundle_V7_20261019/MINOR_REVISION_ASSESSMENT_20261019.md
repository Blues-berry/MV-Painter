# 最后一轮小修：意见分析与修改范围

本次决定为 **Accept After Minor Revision**，对应 CAG-D-26-00962R1。意见认可此前对审稿问题的处理，要求完成贡献定位、结论边界和复现说明的最后整理。它没有提出新增实验、重新选择图例或更改统计分析的要求。

## 核验的唯一基准

- 最新 V6 投稿包：`../V6_EVALUATION_FINAL_20261015/CAG-D-26-00962_R2_V6_EVALUATION_FINAL_20261015.zip`。
- SHA-256：`53caf664b0bf0b28d3d46a55fc864b0527dcbbba62be7a4d6a9b906efa55bcfd`。
- 外层 ZIP 与已解压目录逐文件一致；两个独立 LaTeX 包中的源文件与本地 V6 重建源码一致。
- 本轮 V7 是该包的延续小修，V6 包保留。

## 对意见的判断及实际处理

| 意见 | V6 实际状态 | V7 处理 |
| --- | --- | --- |
| 明确实证贡献 | 题名、摘要和 Introduction 已是 evaluation 定位；但贡献段落仍夹杂较多历史解释 | 用三项实证发现直接组织贡献：实际执行的控制、强基线与时间分配、最终烘焙资产及接口边界；摘要和结论同步 |
| 不将 C3 说成总体更优 | 正文已给出 Fixed High/Generic Linear 的四指标优势和 middle-window 主检验未检出优势 | 在贡献段和 Section 4.1 直接说明 C3 是固定评价对象，不支持一般优越性推荐；保留全部统计结果 |
| 收紧纹理保留与推广主张 | 正文已区分 LPIPS、参考外观、PBR 和不同接口；主要问题在概括层 | 把小幅改善明确为 Late-high 相对 Fixed Mean 的局部 LPIPS 降低；Highlights 同时交代独立 GSO bake 未检出同样收益，将 transfer 表述限制为现有结果未建立推广结论 |
| 汇总可复现细节 | 设置、哈希和分析家族分散在 Table 1、S1–S8；主文复现段仅两句 | 扩写 Section 3.5 的集中摘要，在 S1 新增不改变编号的设置汇总，说明 checkpoint/runner、采样、种子、caps、统计单位、bake 相机与数据访问范围 |

## 两处有实际依据的附加编辑修正

1. V6 Highlights 的 “equal overall strength” 不能准确表达相同的 applied-scale sums，因为实际 residual corrections 仍依赖状态。本轮改为 **matched applied-scale sums**。
2. V6 Highlights 的 “shows no transferable advantage” 容易将未建立推广证据解读成已经证明不存在推广效应。本轮改为 **do not establish schedule transfer**。

公开 v1.0.1 数据仓库实际包含筛选后的指标 CSV、数据字典和来源元数据，没有完整实验脚本、模型权重和生成图档案。Supplement 中若干 `data/`、`scripts/` 路径属于内部证据档案。本轮明确这一区别，使可复现说明与实际可访问文件一致；不声称公开子集能够精确重算全部对象的统计结果。

## 交付原则

- Figure 1–4、Supplement 原有图表、CSV、视频和全部冻结数值保持一致。
- 这轮回复仅逐项回答当前小修意见，不重复上一轮五页历史回复。
- 新 Marked Manuscript 对比上一轮 V6；删除内容省略，新增和替换内容标红。
- 主文与 Supplement 的 LaTeX 继续独立打包；回复提供 PDF 和可编辑 DOCX。
- 伦理、资金和已处理的 AI 披露不属于本轮修订范围。
- 论文系统中的下一轮版本后缀和文件分类以作者进入现有修稿入口后的实际界面为准；内部 V7 不等于期刊分配的修稿编号。

完成构建和文件核验后，以新包的 `PACKAGE_MANIFEST.json` 和 SHA-256 清单记录实际页数、文件范围及核验结果。
