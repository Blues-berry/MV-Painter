Computers & Graphics — V7 minor-revision handoff, 2026-10-19

Decision on CAG-D-26-00962R1: Accept After Minor Revision.
This is a continuation of the verified V6 submission. The V6 package is retained unchanged.

Current pages: clean manuscript 13; marked manuscript 13; Supplement 72; response 2.
UPLOAD_FILES contains 23 prepared journal items, including matching response PDF/DOCX and separate standalone main/Supplement LaTeX source ZIPs.

Changes address the four current recommendations: explicit empirical findings; no general C3-superiority recommendation; bounded appearance/transfer claims; a consolidated reproducibility summary and accurate public-record scope. Five Highlights are aligned with those findings. The current response answers these minor-revision recommendations without repeating the previous five-page historical response.

No experiment, statistic, cohort, generated image, Figure 1–4, existing supplementary figure/table, CSV or video has changed. A long existing Supplement filename/object name now wraps within the text margin.

The marked manuscript compares against the prior V6 source, not the original 01549. New/replacement text is red; deleted text is absent. Main figures remain on pp. 4, 8, 9 and 10. The Supplement grows by one page for the reproducibility summary; existing numbered figures/tables retain their numbers.

The public release remains DOI 10.5281/zenodo.23383807 (v1.0.1). Its limited metrics/provenance scope is distinguished from internal study records and generation requirements.

See the analysis, manifest and provenance files for exact scope, source/archive hashes and validation. These handoff files and the outer ZIP are local documentation rather than journal upload items.
